package com.bezkoder.spring.jpa.query.controller;

import com.bezkoder.spring.jpa.query.model.Tutorial;
import com.bezkoder.spring.jpa.query.repository.TutorialRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/tutorial")
public class TutorialController {
    @Autowired
    private TutorialRepository tutorialRepository;
    @PostMapping("/save")
    public ResponseEntity<Tutorial> saveTutorial(@Valid @RequestBody Tutorial tutorial) {
        return new ResponseEntity<Tutorial>(tutorialRepository.save(tutorial), HttpStatus.CREATED);
    }

    @GetMapping("/findAllSortedByTitle")
    public ResponseEntity<List<Tutorial>> findAllSortedByTitle() {
        return new ResponseEntity<List<Tutorial>>(tutorialRepository.findAllSortedByTitle(), HttpStatus.CREATED);
    }

    @GetMapping("/findAllActiveTutorials")
    public ResponseEntity<Collection<Tutorial>> findAllActiveTutorials() {
        return new ResponseEntity<Collection<Tutorial>>(tutorialRepository.findAllActiveTutorials(), HttpStatus.CREATED);
    }

    @GetMapping("/findAllTutorialsSortByDescription")
    public ResponseEntity<Collection<Tutorial>> findAllTutorialsSortByName(Sort sort) {
        return new ResponseEntity<Collection<Tutorial>>(tutorialRepository.findAllTutorialsSortByName(Sort.by("description")), HttpStatus.resolve(200));
    }

    @GetMapping("/getAllTutorialsPage")
    public ResponseEntity<Map<String, Object>> getAllTutorialsPage(
            @RequestParam(required = false) String title,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "3") int size,
            @RequestParam(defaultValue = "id,asc") String[] sort) {

        try {
            List<Sort.Order> orders = new ArrayList<Sort.Order>();

            if (sort[0].contains(",")) {
                // will sort more than 2 fields
                // sortOrder="field, direction"
                for (String sortOrder : sort) {
                    String[] _sort = sortOrder.split(",");
                    orders.add(new Sort.Order(getSortDirection(_sort[1]), _sort[0]));
                }
            } else {
                // sort=[field, direction]
                orders.add(new Sort.Order(getSortDirection(sort[1]), sort[0]));
            }

            List<Tutorial> tutorials = new ArrayList<Tutorial>();
            Pageable pagingSort = PageRequest.of(page, size, Sort.by(orders));

            Page<Tutorial> pageTuts;
            if (title == null)
                pageTuts = tutorialRepository.findAll(pagingSort);
            else
                pageTuts = tutorialRepository.findAllTutorialsWithPagination(title, pagingSort);

            tutorials = pageTuts.getContent();

            Map<String, Object> response = new HashMap<>();
            response.put("tutorials", tutorials);
            response.put("currentPage", pageTuts.getNumber());
            response.put("totalItems", pageTuts.getTotalElements());
            response.put("totalPages", pageTuts.getTotalPages());

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private Sort.Direction getSortDirection(String direction) {
        if (direction.equals("asc")) {
            return Sort.Direction.ASC;
        } else if (direction.equals("desc")) {
            return Sort.Direction.DESC;
        }

        return Sort.Direction.ASC;
    }

    @GetMapping("/findTutorialByPublishedAndTitle")
    public ResponseEntity<Tutorial> findTutorialByPublishedAndTitle(Boolean published, String title) {
        return new ResponseEntity<Tutorial>(tutorialRepository.findTutorialByPublishedAndTitle(published, title), HttpStatus.CREATED);
    }

    @GetMapping("/findTutorialByPublishedAndTitleNamedParams")
    public ResponseEntity<Tutorial> findTutorialByPublishedAndTitleNamedParams(
            @Param("published") Boolean published,
            @Param("title") String title) {
        return new ResponseEntity<Tutorial>(tutorialRepository.findTutorialByPublishedAndTitleNamedParams(published,title), HttpStatus.resolve(200));
    }

    @GetMapping("/findTutorialsByTitleList")
    public ResponseEntity<List<Tutorial>> findTutorialsByTitleList(

            @Param("title") String title) {
        return new ResponseEntity<List<Tutorial>>(tutorialRepository.findTutorialsByTitleList(title), HttpStatus.resolve(200));
    }
//
//    @GetMapping("/fetch/{id}")
//    public Tutorial getProduct(@PathVariable Long id) throws ProductNotFoundException {
//        return tutorialRepository.fetchProduct(id);
 //   }
}
